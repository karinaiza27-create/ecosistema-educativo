// publico/js/nucleo/catalogo-actividades.js · Catálogo central de actividades y juegos pedagógicos

export const ACTIVIDADES = [
  {
    id: "ahorcado",
    texto: "Ahorcado",
    descripcion: "Adivina la palabra del tema",
    href: "/paginas/ahorcado.html"
  },
  {
    id: "pareja",
    texto: "Encuentra la pareja",
    descripcion: "Relaciona conceptos y definiciones",
    href: "/paginas/pareja.html"
  },
  {
    id: "canciones",
    texto: "Canciones del tema",
    descripcion: "Aprende con música",
    href: "/paginas/canciones.html"
  },
  {
    id: "quiz",
    texto: "Quiz por niveles",
    descripcion: "Supera 5 niveles y gana diplomas",
    href: "/paginas/quiz.html"
  },
  {
    id: "sopa-letras",
    texto: "Sopa de letras",
    descripcion: "Encuentra los conceptos del tema",
    href: "/paginas/sopa-letras.html"
  },
  {
    id: "crucigrama",
    texto: "Crucigrama",
    descripcion: "Completa las palabras con sus pistas",
    href: "/paginas/crucigrama.html"
  },
  {
    id: "tutor",
    texto: "Tutor socrático",
    descripcion: "Dialoga y aprende con Sócrates",
    href: "/paginas/tutor.html"
  }
];

export default ACTIVIDADES;
